namespace Audial.Utils;

internal enum RunState
{
	Running,
	Paused,
	Stopped
}
