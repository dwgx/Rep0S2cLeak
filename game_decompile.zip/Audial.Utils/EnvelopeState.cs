namespace Audial.Utils;

internal enum EnvelopeState
{
	Idle,
	Attack,
	Decay,
	Release
}
