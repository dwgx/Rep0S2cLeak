namespace Audial.Utils;

public static class Settings
{
	public static float SampleRate;
}
