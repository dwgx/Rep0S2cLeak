namespace Audial;

public enum FilterState
{
	Bypass,
	LowPass,
	LowShelf,
	HighPass,
	HighShelf,
	BandPass,
	BandAdd
}
