using UnityEngine;

public class CrawlTrigger : MonoBehaviour
{
}
