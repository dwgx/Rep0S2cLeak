public class DoorTrap : Trap
{
}
