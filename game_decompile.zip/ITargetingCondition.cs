using UnityEngine;

public interface ITargetingCondition
{
	bool CustomTargetingCondition(GameObject target);
}
