namespace LeastSquares.Overtone;

public class TTSResult
{
	public float[] Samples;

	public uint Channels;

	public uint SampleRate;
}
