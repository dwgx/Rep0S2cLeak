using UnityEngine;

public class EnemyHeartHuggerCuteFace : MonoBehaviour
{
	public Transform mouthClosed;

	public Transform mouthOpen;
}
