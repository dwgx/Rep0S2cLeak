using UnityEngine;

public class DebugComputerCheck : MonoBehaviour
{
	private void Start()
	{
		base.gameObject.SetActive(value: false);
	}
}
