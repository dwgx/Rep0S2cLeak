public static class GameDirectorStatic
{
	public static bool CatchCutscenePlayed;
}
