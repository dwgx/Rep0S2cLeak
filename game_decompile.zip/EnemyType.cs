public enum EnemyType
{
	VeryLight,
	Light,
	Medium,
	Heavy,
	VeryHeavy
}
