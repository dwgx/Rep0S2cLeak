public class LightningTrap : Trap
{
}
