using UnityEngine;

public class DebugJannek : MonoBehaviour
{
}
