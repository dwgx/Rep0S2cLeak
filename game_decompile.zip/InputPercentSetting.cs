public enum InputPercentSetting
{
	MouseSensitivity
}
