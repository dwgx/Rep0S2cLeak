using UnityEngine;

public class ExpressionBubble : MonoBehaviour
{
	private void Start()
	{
	}

	private void Update()
	{
	}
}
