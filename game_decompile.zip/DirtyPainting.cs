using UnityEngine;

public class DirtyPainting : MonoBehaviour
{
	public CanvasHandler CanvasHandler;
}
