using UnityEngine;

[ExecuteAlways]
public class BotSystemSpringPoseAnimatorGUI : MonoBehaviour
{
}
